import { useEffect, useRef, useState } from 'react';
import { 
  Phone, Mail, Clock, MapPin, Instagram, Facebook, 
  Menu, X, Star, Check, Calendar,
  Sparkles, Heart, Shield, MessageCircle, ArrowRight
} from 'lucide-react';

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';

// Lotus SVG Icon
const LotusIcon = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" fill="currentColor" className={className}>
    <path d="M24 4C24 4 18 12 18 20C18 28 24 36 24 36C24 36 30 28 30 20C30 12 24 4 24 4Z" opacity="0.9"/>
    <path d="M24 36C24 36 16 32 10 24C4 16 8 8 8 8C8 8 16 12 20 20C24 28 24 36 24 36Z" opacity="0.7"/>
    <path d="M24 36C24 36 32 32 38 24C44 16 40 8 40 8C40 8 32 12 28 20C24 28 24 36 24 36Z" opacity="0.7"/>
    <path d="M24 36C24 36 20 40 14 40C8 40 4 36 4 36C4 36 10 32 16 32C22 32 24 36 24 36Z" opacity="0.5"/>
    <path d="M24 36C24 36 28 40 34 40C40 40 44 36 44 36C44 36 38 32 32 32C26 32 24 36 24 36Z" opacity="0.5"/>
    <ellipse cx="24" cy="42" rx="8" ry="3" opacity="0.3"/>
  </svg>
);

// WhatsApp Button
const WhatsAppButton = () => (
  <a
    href="https://wa.me/201093069700?text=Hi%20I%20want%20to%20book%20an%20appointment"
    target="_blank"
    rel="noopener noreferrer"
    className="fixed bottom-6 right-6 z-50 bg-green-500 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
    aria-label="Chat on WhatsApp"
  >
    <MessageCircle className="w-6 h-6" />
    <span className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-gray-800 text-white text-sm px-3 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
      Chat with us!
    </span>
  </a>
);

// Top Info Bar
const TopInfoBar = () => (
  <div className="bg-cream border-b border-gold/20 py-2 px-4 hidden lg:block">
    <div className="max-w-7xl mx-auto flex items-center justify-between text-sm">
      <div className="flex items-center gap-6">
        <a href="tel:01093069700" className="flex items-center gap-2 text-teal hover:text-gold transition-colors">
          <Phone className="w-4 h-4" />
          <span>0109 306 9700</span>
        </a>
        <a href="mailto:bloombeautyclinic0@gmail.com" className="flex items-center gap-2 text-gray-600 hover:text-teal transition-colors">
          <Mail className="w-4 h-4" />
          <span>bloombeautyclinic0@gmail.com</span>
        </a>
      </div>
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 text-gray-600">
          <Clock className="w-4 h-4" />
          <span>Sat–Thu: 10:00–22:00 | Fri: 14:00–22:00</span>
        </div>
        <div className="flex items-center gap-3">
          <a href="https://instagram.com/bloomaestheticsclinics" target="_blank" rel="noopener noreferrer" className="text-teal hover:text-gold transition-colors">
            <Instagram className="w-4 h-4" />
          </a>
          <a href="https://facebook.com/BloomAestheticsNewCairo" target="_blank" rel="noopener noreferrer" className="text-teal hover:text-gold transition-colors">
            <Facebook className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  </div>
);

// Navigation
const Navigation = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Services', href: '#services' },
    { label: 'Doctors', href: '#doctors' },
    { label: 'Results', href: '#results' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-4'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a href="#" className="flex items-center gap-2">
            <LotusIcon className="w-8 h-8 text-teal" />
            <span className="font-serif text-xl font-semibold text-teal">Bloom</span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-gray-700 hover:text-teal transition-colors relative group"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <a
              href="https://wa.me/201093069700?text=Hi%20I%20want%20to%20book%20an%20appointment"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-gold hover:bg-gold/90 text-white rounded-full px-6">
                Book Now
              </Button>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 text-teal"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden absolute top-full left-0 right-0 bg-white shadow-lg transition-all duration-300 ${
        isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
      }`}>
        <div className="px-4 py-6 space-y-4">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="block text-lg font-medium text-gray-700 hover:text-teal transition-colors"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://wa.me/201093069700?text=Hi%20I%20want%20to%20book%20an%20appointment"
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full"
          >
            <Button className="w-full bg-gold hover:bg-gold/90 text-white rounded-full">
              Book Now
            </Button>
          </a>
        </div>
      </div>
    </nav>
  );
};

// Hero Section
const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section ref={sectionRef} className="relative min-h-screen flex items-center overflow-hidden bg-cream pt-20">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/10">BLOOM</span>
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-0">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Hero Image */}
          <div className={`relative transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}>
            <div className="relative rounded-3xl overflow-hidden shadow-luxury-lg">
              <img
                src="/images/hero_face_relax.jpg"
                alt="Natural beauty treatment at Bloom Clinics"
                className="w-full h-[50vh] lg:h-[70vh] object-cover"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-teal/20 to-transparent" />
            </div>
            {/* Floating Badge */}
            <div className="absolute -bottom-4 -right-4 lg:bottom-8 lg:right-8 bg-white rounded-2xl shadow-luxury p-4 flex items-center gap-3">
              <div className="flex -space-x-2">
                <div className="w-10 h-10 rounded-full bg-teal flex items-center justify-center text-white text-sm font-bold">4.1</div>
              </div>
              <div>
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-4 h-4 ${i < 4 ? 'text-gold fill-gold' : 'text-gold/50'}`} />
                  ))}
                </div>
                <p className="text-xs text-gray-600">63 Google Reviews</p>
              </div>
            </div>
          </div>

          {/* Hero Content */}
          <div className={`lg:pl-8 transition-all duration-1000 delay-300 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="gold-divider" />
              <span className="text-gold text-sm font-medium tracking-widest uppercase">
                Bloom Clinics New Cairo
              </span>
            </div>
            
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-teal leading-tight mb-6">
              Natural · Elegant · Balanced
            </h1>
            
            <p className="text-lg text-gray-600 mb-8 max-w-lg leading-relaxed">
              Aesthetic medicine and dental care designed around you. Experience premium treatments 
              in a serene, luxurious environment.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <a
                href="https://wa.me/201093069700?text=Hi%20I%20want%20to%20book%20an%20appointment"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="btn-primary flex items-center gap-2 w-full sm:w-auto">
                  <Calendar className="w-5 h-5" />
                  Book a Consultation
                </Button>
              </a>
              <a href="#services">
                <Button variant="outline" className="border-teal text-teal hover:bg-teal hover:text-white rounded-full px-8 py-4 w-full sm:w-auto">
                  Explore Services
                </Button>
              </a>
            </div>

            <div className="flex items-center gap-2 text-sm text-gray-500">
              <MapPin className="w-4 h-4 text-gold" />
              <span>New Cairo · Sodic East Town</span>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Lotus */}
      <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}>
        <LotusIcon className="w-12 h-12 text-teal/80 float-animation" />
      </div>
    </section>
  );
};

// Services Section
const ServicesSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const aestheticServices = [
    { name: 'Botox', description: 'Anti-wrinkle treatment' },
    { name: 'Lip Fillers', description: 'Volume & definition' },
    { name: 'PDRN Salmon DNA', description: 'Deep repair & hydration' },
    { name: 'Laser Treatments', description: 'Rejuvenation, pigmentation, hair removal' },
    { name: 'Dermal Fillers', description: 'Contour & volume restoration' },
    { name: 'Radiant Skincare', description: 'Facials, peels, hydrafacials' },
  ];

  const dentalServices = [
    { name: 'General Dentistry', description: 'Comprehensive dental care' },
    { name: 'Cosmetic Dentistry', description: 'Veneers & smile makeovers' },
    { name: 'Orthodontics', description: 'Braces & clear aligners' },
    { name: 'Teeth Whitening', description: 'Professional brightening' },
  ];

  return (
    <section ref={sectionRef} id="services" className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">SERVICES</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="gold-divider" />
            <span className="text-gold text-sm font-medium tracking-widest uppercase">Our Services</span>
            <div className="gold-divider" />
          </div>
          <h2 className="font-serif text-4xl lg:text-5xl text-teal mb-4">
            Aesthetic & Dental Excellence
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover our comprehensive range of treatments designed to enhance your natural beauty 
            and maintain your dental health.
          </p>
        </div>

        {/* Services Tabs */}
        <Tabs defaultValue="aesthetics" className={`w-full transition-all duration-700 delay-200 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <TabsList className="flex justify-center mb-12 bg-white/50 p-2 rounded-full w-fit mx-auto">
            <TabsTrigger 
              value="aesthetics" 
              className="px-8 py-3 rounded-full data-[state=active]:bg-teal data-[state=active]:text-white transition-all"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Aesthetics
            </TabsTrigger>
            <TabsTrigger 
              value="dental"
              className="px-8 py-3 rounded-full data-[state=active]:bg-teal data-[state=active]:text-white transition-all"
            >
              <Heart className="w-4 h-4 mr-2" />
              Dental
            </TabsTrigger>
          </TabsList>

          <TabsContent value="aesthetics">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="rounded-3xl overflow-hidden shadow-luxury">
                <img
                  src="/images/services_aesthetics_room.jpg"
                  alt="Aesthetics treatment room"
                  className="w-full h-[300px] lg:h-[400px] object-cover"
                  loading="lazy"
                />
              </div>
              <div className="space-y-6">
                <h3 className="font-serif text-3xl text-teal">Aesthetic Treatments</h3>
                <p className="text-gray-600">
                  Botox, fillers, laser, and skin rejuvenation—personalized plans for natural results.
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  {aestheticServices.map((service, index) => (
                    <div 
                      key={service.name}
                      className="flex items-start gap-3 p-4 bg-white/60 rounded-2xl hover:bg-white transition-colors"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-teal">{service.name}</h4>
                        <p className="text-sm text-gray-500">{service.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <a
                  href="https://wa.me/201093069700?text=Hi%20I'm%20interested%20in%20your%20aesthetic%20services"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="btn-primary mt-4">
                    Explore Aesthetics
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="dental">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-6 order-2 lg:order-1">
                <h3 className="font-serif text-3xl text-teal">Dental Care</h3>
                <p className="text-gray-600">
                  Cosmetic dentistry, orthodontics, whitening, and general care in a calm, modern environment.
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  {dentalServices.map((service, index) => (
                    <div 
                      key={service.name}
                      className="flex items-start gap-3 p-4 bg-white/60 rounded-2xl hover:bg-white transition-colors"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <Check className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-teal">{service.name}</h4>
                        <p className="text-sm text-gray-500">{service.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <a
                  href="https://wa.me/201093069700?text=Hi%20I'm%20interested%20in%20your%20dental%20services"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="btn-primary mt-4">
                    Explore Dental
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </div>
              <div className="rounded-3xl overflow-hidden shadow-luxury order-1 lg:order-2">
                <img
                  src="/images/services_dental_chair.jpg"
                  alt="Dental clinic interior"
                  className="w-full h-[300px] lg:h-[400px] object-cover"
                  loading="lazy"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

// Why Choose Us Section
const WhyChooseSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    { icon: Shield, title: 'Board-certified specialists', description: 'Expert doctors with years of experience' },
    { icon: Check, title: 'Transparent pricing & plans', description: 'No hidden fees, clear upfront costs' },
    { icon: Heart, title: 'Gentle techniques & follow-up', description: 'Comfortable care with ongoing support' },
  ];

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-teal overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-cream/10">TRUST</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className={`relative transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}>
            <div className="rounded-3xl overflow-hidden shadow-luxury-lg">
              <img
                src="/images/trust_hand_treatment.jpg"
                alt="Gentle treatment at Bloom Clinics"
                className="w-full h-[400px] lg:h-[500px] object-cover"
                loading="lazy"
              />
            </div>
            {/* Decorative Element */}
            <div className="absolute -bottom-6 -left-6 w-32 h-32 border-2 border-gold/30 rounded-3xl" />
          </div>

          {/* Content */}
          <div className={`lg:pl-8 transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-0.5 bg-gold" />
              <span className="text-gold text-sm font-medium tracking-widest uppercase">Why Bloom</span>
            </div>
            
            <h2 className="font-serif text-4xl lg:text-5xl text-cream leading-tight mb-6">
              Safety, clarity, and care—every step.
            </h2>
            
            <p className="text-lg text-cream/80 mb-10 leading-relaxed">
              We combine medical rigor with an aesthetic eye. Every treatment is explained, 
              every question welcomed. Your comfort and satisfaction are our priorities.
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => (
                <div 
                  key={feature.title}
                  className="flex items-start gap-4 p-4 bg-white/10 rounded-2xl backdrop-blur-sm"
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <h4 className="font-medium text-cream text-lg">{feature.title}</h4>
                    <p className="text-cream/70 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Doctors Section
const DoctorsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const doctors = [
    {
      name: 'Dr. Islam',
      role: 'Aesthetic Specialist',
      description: 'Focuses on natural enhancement and skin health.',
      image: '/images/doctor_aesthetic_profile.jpg',
    },
    {
      name: 'Dr. Walid',
      role: 'Dental Surgeon',
      description: 'Smile design, cosmetics, and gentle procedures.',
      image: '/images/doctor_dental_profile.jpg',
    },
  ];

  return (
    <section ref={sectionRef} id="doctors" className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">DOCTORS</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="gold-divider" />
            <span className="text-gold text-sm font-medium tracking-widest uppercase">Our Team</span>
            <div className="gold-divider" />
          </div>
          <h2 className="font-serif text-4xl lg:text-5xl text-teal mb-4">
            Meet the Doctors
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Experienced professionals dedicated to your care and beauty.
          </p>
        </div>

        {/* Doctors Grid */}
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {doctors.map((doctor, index) => (
            <div 
              key={doctor.name}
              className={`group transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 200}ms` }}
            >
              <div className="card-luxury overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src={doctor.image}
                    alt={doctor.name}
                    className="w-full h-[350px] lg:h-[450px] object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-teal/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="p-6 lg:p-8">
                  <h3 className="font-serif text-2xl lg:text-3xl text-teal mb-1">{doctor.name}</h3>
                  <p className="text-gold font-medium mb-3">{doctor.role}</p>
                  <p className="text-gray-600 text-sm">{doctor.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Before & After Section
const ResultsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} id="results" className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">RESULTS</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="gold-divider" />
            <span className="text-gold text-sm font-medium tracking-widest uppercase">Before & After</span>
            <div className="gold-divider" />
          </div>
          <h2 className="font-serif text-4xl lg:text-5xl text-teal mb-4">
            See the Change
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Real patients. Real outcomes. Subtle and natural.
          </p>
        </div>

        {/* Before & After Images */}
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 items-center">
          {/* Before */}
          <div className={`relative transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}>
            <div className="relative rounded-3xl overflow-hidden shadow-luxury">
              <img
                src="/images/results_before_face.jpg"
                alt="Before treatment"
                className="w-full h-[400px] lg:h-[500px] object-cover"
                loading="lazy"
              />
              <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full">
                <span className="text-teal font-medium">Before</span>
              </div>
            </div>
          </div>

          {/* After */}
          <div className={`relative transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
          }`}>
            <div className="relative rounded-3xl overflow-hidden shadow-luxury">
              <img
                src="/images/results_after_face.jpg"
                alt="After treatment"
                className="w-full h-[400px] lg:h-[500px] object-cover"
                loading="lazy"
              />
              <div className="absolute top-6 left-6 bg-gold/90 backdrop-blur-sm px-4 py-2 rounded-full">
                <span className="text-white font-medium">After</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center Label */}
        <div className={`text-center mt-12 transition-all duration-700 delay-400 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <p className="text-gray-600 italic">
            "The team made me feel safe and heard. My results look natural—exactly what I wanted."
          </p>
          <p className="text-gold font-medium mt-2">— Nour D.</p>
        </div>
      </div>
    </section>
  );
};

// Testimonials Section
const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const testimonials = [
    {
      text: "I would like to express my sincere gratitude to Dr. Islam and Dr. Walid for their exceptional care and professionalism.",
      author: "Mohamed Gabr",
      rating: 5,
    },
    {
      text: "I had a wonderful experience at Bloom Clinic! The staff were super friendly and welcoming.",
      author: "Nour Dorgham",
      rating: 5,
    },
    {
      text: "The clinic is clean, modern, and welcoming. I tried laser treatment and I'm beyond happy.",
      author: "Shrouka Aboelmagd",
      rating: 5,
    },
  ];

  const tags = ['Welcoming Staff', 'Clear Explanations', 'Comfortable Clinic', 'Cozy Atmosphere'];

  return (
    <section ref={sectionRef} id="reviews" className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">REVIEWS</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="gold-divider" />
            <span className="text-gold text-sm font-medium tracking-widest uppercase">Testimonials</span>
            <div className="gold-divider" />
          </div>
          <h2 className="font-serif text-4xl lg:text-5xl text-teal mb-4">
            What Our Patients Say
          </h2>
          
          {/* Tags */}
          <div className="flex flex-wrap justify-center gap-3 mt-6">
            {tags.map((tag) => (
              <span 
                key={tag}
                className="px-4 py-2 bg-white/60 border border-gold/20 rounded-full text-sm text-gray-600"
              >
                <Check className="w-4 h-4 inline mr-1 text-gold" />
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={testimonial.author}
              className={`card-luxury p-6 lg:p-8 transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-gold fill-gold" />
                ))}
              </div>
              
              {/* Quote */}
              <p className="text-gray-700 leading-relaxed mb-6">
                "{testimonial.text}"
              </p>
              
              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-teal/10 rounded-full flex items-center justify-center">
                  <span className="text-teal font-medium">
                    {testimonial.author.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>
                <span className="font-medium text-teal">{testimonial.author}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Google Rating */}
        <div className={`text-center mt-12 transition-all duration-700 delay-500 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}>
          <div className="inline-flex items-center gap-4 bg-white/60 rounded-2xl px-6 py-4">
            <div className="flex items-center gap-2">
              <span className="text-3xl font-serif font-bold text-teal">4.1</span>
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-4 h-4 ${i < 4 ? 'text-gold fill-gold' : 'text-gold/50'}`} />
                ))}
              </div>
            </div>
            <div className="text-left">
              <p className="text-sm text-gray-600">Google Rating</p>
              <p className="text-sm text-gray-500">63 reviews</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Visit Us Section
const VisitSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">VISIT</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Info */}
          <div className={`transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="gold-divider" />
              <span className="text-gold text-sm font-medium tracking-widest uppercase">Location</span>
            </div>
            
            <h2 className="font-serif text-4xl lg:text-5xl text-teal leading-tight mb-8">
              Visit Bloom Clinics
            </h2>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <h4 className="font-medium text-teal text-lg">Address</h4>
                  <p className="text-gray-600">
                    Sodic East Town — EDNC — Gate 9, Building 4, Clinic 7 (Unit 4-4-7), 
                    Fifth Settlement, New Cairo, Egypt
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <h4 className="font-medium text-teal text-lg">Working Hours</h4>
                  <p className="text-gray-600">Saturday – Thursday: 10:00 AM – 10:00 PM</p>
                  <p className="text-gray-600">Friday: 2:00 PM – 10:00 PM</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-teal/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-teal" />
                </div>
                <div>
                  <h4 className="font-medium text-teal text-lg">Phone</h4>
                  <a href="tel:01093069700" className="text-gray-600 hover:text-teal transition-colors">
                    0109 306 9700
                  </a>
                </div>
              </div>
            </div>

            <a
              href="https://maps.google.com/?q=Sodic+East+Town+New+Cairo"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block mt-8"
            >
              <Button className="btn-secondary flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Get Directions
              </Button>
            </a>
          </div>

          {/* Map */}
          <div className={`transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
          }`}>
            <div className="rounded-3xl overflow-hidden shadow-luxury h-[400px] lg:h-[500px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3456.789!2d31.456!3d30.012!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzDCsDAwJzQzLjIiTiAzMcKwMjcnMjEuNiJF!5e0!3m2!1sen!2seg!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Bloom Clinics Location"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Contact/Book Section
const ContactSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    message: '',
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const whatsappMessage = `Hi, I'm ${formData.name}. I'm interested in ${formData.service}. ${formData.message}`;
    window.open(`https://wa.me/201093069700?text=${encodeURIComponent(whatsappMessage)}`, '_blank');
  };

  return (
    <section ref={sectionRef} id="contact" className="relative py-20 lg:py-32 bg-cream overflow-hidden">
      {/* Oversized Background Text */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span className="oversized-text text-teal/5">BOOK</span>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className={`relative transition-all duration-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <div className="rounded-3xl overflow-hidden shadow-luxury">
              <img
                src="/images/book_reception_scene.jpg"
                alt="Bloom Clinics reception"
                className="w-full h-[400px] lg:h-[500px] object-cover"
                loading="lazy"
              />
            </div>
          </div>

          {/* Form */}
          <div className={`transition-all duration-700 delay-200 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}>
            <div className="flex items-center gap-3 mb-4">
              <div className="gold-divider" />
              <span className="text-gold text-sm font-medium tracking-widest uppercase">Appointment</span>
            </div>
            
            <h2 className="font-serif text-4xl lg:text-5xl text-teal leading-tight mb-4">
              Book Your Consultation
            </h2>
            
            <p className="text-gray-600 mb-8">
              Tell us what you're looking for. We'll reply within one business day.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-white/60 focus:outline-none focus:ring-2 focus:ring-teal/50 transition-all"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
                <input
                  type="tel"
                  placeholder="Phone Number"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-white/60 focus:outline-none focus:ring-2 focus:ring-teal/50 transition-all"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
              
              <input
                type="email"
                placeholder="Email Address"
                className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-white/60 focus:outline-none focus:ring-2 focus:ring-teal/50 transition-all"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
              
              <select
                required
                className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-white/60 focus:outline-none focus:ring-2 focus:ring-teal/50 transition-all appearance-none"
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
              >
                <option value="">Select a Service</option>
                <option value="Botox">Botox</option>
                <option value="Lip Fillers">Lip Fillers</option>
                <option value="Laser Treatment">Laser Treatment</option>
                <option value="Dental Consultation">Dental Consultation</option>
                <option value="Teeth Whitening">Teeth Whitening</option>
                <option value="Other">Other</option>
              </select>
              
              <textarea
                placeholder="Your Message"
                rows={4}
                className="w-full px-4 py-3 rounded-xl border border-gold/20 bg-white/60 focus:outline-none focus:ring-2 focus:ring-teal/50 transition-all resize-none"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              />
              
              <Button type="submit" className="btn-primary w-full">
                <MessageCircle className="w-5 h-5 mr-2" />
                Request Appointment
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-500 text-sm">
                Prefer to call?{' '}
                <a href="tel:01093069700" className="text-teal hover:text-gold transition-colors font-medium">
                  0109 306 9700
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// Final CTA Banner
const CTABanner = () => (
  <section className="relative py-16 bg-teal overflow-hidden">
    <div className="absolute inset-0 opacity-10">
      <div className="absolute inset-0 bg-gradient-to-r from-gold/20 to-transparent" />
    </div>
    
    <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <h2 className="font-serif text-3xl lg:text-4xl text-cream mb-4">
        Ready to Transform Your Look?
      </h2>
      <p className="text-cream/80 mb-8">
        Book your consultation today and discover the Bloom difference.
      </p>
      <a
        href="https://wa.me/201093069700?text=Hi%20I%20want%20to%20book%20an%20appointment"
        target="_blank"
        rel="noopener noreferrer"
      >
        <Button className="bg-gold hover:bg-gold/90 text-white rounded-full px-10 py-4 text-lg">
          <Calendar className="w-5 h-5 mr-2" />
          Book Now
        </Button>
      </a>
    </div>
  </section>
);

// Footer
const Footer = () => (
  <footer className="bg-teal text-cream py-16">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="grid md:grid-cols-4 gap-8 lg:gap-12">
        {/* Brand */}
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <LotusIcon className="w-10 h-10 text-gold" />
            <span className="font-serif text-2xl font-semibold">Bloom Clinics</span>
          </div>
          <p className="text-cream/70 mb-4 max-w-md">
            Natural · Elegant · Balanced. Aesthetic medicine and dental care designed around you.
          </p>
          <div className="flex items-center gap-4">
            <a 
              href="https://instagram.com/bloomaestheticsclinics" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors"
            >
              <Instagram className="w-5 h-5" />
            </a>
            <a 
              href="https://facebook.com/BloomAestheticsNewCairo" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors"
            >
              <Facebook className="w-5 h-5" />
            </a>
            <a 
              href="https://wa.me/201093069700" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-gold transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-serif text-lg mb-4">Quick Links</h4>
          <ul className="space-y-2">
            {['Services', 'Doctors', 'Results', 'Reviews', 'Contact'].map((link) => (
              <li key={link}>
                <a href={`#${link.toLowerCase()}`} className="text-cream/70 hover:text-gold transition-colors">
                  {link}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-serif text-lg mb-4">Contact</h4>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <MapPin className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
              <span className="text-cream/70 text-sm">
                Sodic East Town, Fifth Settlement, New Cairo
              </span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-gold flex-shrink-0" />
              <a href="tel:01093069700" className="text-cream/70 hover:text-gold transition-colors text-sm">
                0109 306 9700
              </a>
            </li>
            <li className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-gold flex-shrink-0" />
              <a href="mailto:bloombeautyclinic0@gmail.com" className="text-cream/70 hover:text-gold transition-colors text-sm">
                bloombeautyclinic0@gmail.com
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 mt-12 pt-8 text-center">
        <p className="text-cream/50 text-sm">
          © {new Date().getFullYear()} Bloom Clinics New Cairo. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

// Main App
function App() {
  return (
    <div className="relative">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Schema.org JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'MedicalBusiness',
            name: 'Bloom Clinics New Cairo',
            description: 'Aesthetic and dental clinic in New Cairo offering Botox, fillers, laser treatments, and dental care.',
            url: 'https://bloomclinics.com',
            telephone: '+201093069700',
            email: 'bloombeautyclinic0@gmail.com',
            address: {
              '@type': 'PostalAddress',
              streetAddress: 'Sodic East Town - EDNC - Gate 9, Building 4, Clinic 7 (Unit 4-4-7), Fifth Settlement',
              addressLocality: 'New Cairo',
              addressCountry: 'EG',
            },
            openingHours: [
              'Sa-Th 10:00-22:00',
              'Fr 14:00-22:00',
            ],
            aggregateRating: {
              '@type': 'AggregateRating',
              ratingValue: '4.1',
              reviewCount: '63',
            },
            priceRange: '$$',
            sameAs: [
              'https://instagram.com/bloomaestheticsclinics',
              'https://facebook.com/BloomAestheticsNewCairo',
            ],
          }),
        }}
      />

      {/* Top Info Bar */}
      <TopInfoBar />
      
      {/* Navigation */}
      <Navigation />
      
      {/* Main Content */}
      <main>
        <HeroSection />
        <ServicesSection />
        <WhyChooseSection />
        <DoctorsSection />
        <ResultsSection />
        <TestimonialsSection />
        <VisitSection />
        <ContactSection />
        <CTABanner />
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* WhatsApp Button */}
      <WhatsAppButton />
    </div>
  );
}

export default App;
